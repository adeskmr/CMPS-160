CMPS 160's assignment 1!

Adesh Kumar
akumar25@ucsc.edu
Fall 2018 CMPS 160
Professor James Davis

Files: 
Driver.html
Lib
	cuon-utils.js
	load-files.js
	webgl-debug.js
	webgl-utils.js
Prog
	eventFunctions.js
	glslFunctions.js
	main.js
	shaders.js
	htmlFunctions.js

Comments:
This assignment got the best of me. I unfortunately didn't understand how to proper update the latest point as that was my lack of understanding on how to do so. However, I was quick to understand how webGL and javascript communicate as well as get the sliders and buttons to work. This was very enjoyable and challenging, I love this stuff and can't wait to get more. But hopefully understand it better.
