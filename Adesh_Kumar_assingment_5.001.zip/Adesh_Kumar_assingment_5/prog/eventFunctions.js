
/**
 * Responsible for initializing buttons, sliders, radio buttons, etc. present
 * within your HTML document.
 */
var shape;
var segs;
var onmousedrag = false;
var isRainbow = false;
var image = new Image(); // Create an image object
var wasdDown = [0, 0, 0, 0];

function initEventHandelers() {
  //Handle mouse
  canvas.onmousemove = mouseMove;
  canvas.onmousedown = function () {
    canvas.requestPointerLock = canvas.requestPointerLock ||
                            canvas.mozRequestPointerLock ||
                            canvas.webkitRequestPointerLock;
    canvas.requestPointerLock();
  }
  //Handle keyboard
  document.defaultView.onkeydown = keyDown;
  document.defaultView.onkeyup = keyUp;

var file = document.getElementById("obj");
file.oninput = function() { 
  if(document.getElementById('addpic').files[0] != undefined) {addTextureToGeometry();}
  addObjectToScene();
 };

// var addObjectButton = document.getElementById("addpic");
// addObjectButton.onclick = function (ev) { 
//   if (document.getElementById('addpic').files[0] != undefined)
//   { addTextureToGeometry(); } 
//   addObjectToScene();  
// };

// var triButton = document.getElementById("tri");
// triButton.onclick = function() { shape = 0; }
// var squButton = document.getElementById("squ");
// squButton.onclick = function() { shape = 1; }
// var cirButton = document.getElementById("cir");
// cirButton.onclick = function() { shape = 2; }
// var cubeButton = document.getElementById("cube");
// cubeButton.onclick = function() { shape = 3; }
// var texturedCube = document.getElementById("texturedCube");
// texturedCube.onclick = function() { }


// shape = 0;
// segs = 12;

// var sizeSlider = document.getElementById("sizeSlider");
// var cir = document.getElementById("cirseg");
// cir.oninput = function() { segs = this.value; }
}


/**
 * Function called upon mouse click or mouse drag. Computes position of cursor,
 * pushes cursor position as GLSL coordinates, and draws.
 *
 * @param {Object} ev The event object containing the mouse's canvas position
 */
function click(ev) {
  var x = ev.clientX; // x coordinate of a mouse pointer
  var y = ev.clientY; // y coordinate of a mouse pointer

  x = ((x) - canvas.width / 2) / (canvas.width / 2);
  y = (canvas.height / 2 - (y)) / (canvas.height / 2);
  coords = "X: " + x + ", Y: " + y; //gets the x and y coordinate 
  sendTextToHTML(coords, "coord"); //send the x and y coordinate to the html

  console.log("hello1")
  
  // if(shape == 0){
  //   tri = new FluctuatingTriangle(sizeSlider.value/200, x, y);
  //   //tri.setColor(RGB);
  //   scene.addGeometry(tri);
  // } else if(shape == 1){
  //   squ = new SpinningSquare(sizeSlider.value/100, x, y);
  //   //squ.setColor(RGB);
  //   scene.addGeometry(squ);
  // } else if(shape == 2){
  //   cir = new Circle(.2, segs, x, y);
  //   //cir.setColor(RGB);
  //   scene.addGeometry(cir);
  // } else if(shape == 3){
  //   cube = new TiltedCube(sizeSlider.value/100, x, y);
  //   //cir.setColor(RGB);
  //   scene.addGeometry(cube);
  // } else if(document.getElementById("addpic").files[0] == undefined){
  //   cube_text = new MultiTextureCube(sizeSlider.value/100, x, y, texture);
  //   //cir.setColor(RGB);
  //   scene.addGeometry(cube_text);
  // } else {
  //   addTextureToGeometry();
  // }

  console.log("hello3")
}

  function addObjectToScene(){
    // let obj = "/external/OBJ/cat.obj"
    ObjString = document.getElementById('obj').files[0];
    var reader = new FileReader();
           reader.onload = function(e) {
               scene.addGeometry(new LoadedOBJ(e.target.result));
           }
           console.log("obj")
           reader.readAsText(ObjString);
    }
    /**
 * Handles mouse moving
 */
function mouseMove(ev) {
  scene.rotateCamera(ev.movementX/10, ev.movementY/10);
}

function keyDown(ev) {
  if(ev.keyCode == 87) { //w
    wasdDown[0] = 1;
  }
  if(ev.keyCode == 65) { //a
    wasdDown[1] = 1;
  }
  if(ev.keyCode == 83) { //s
    wasdDown[2] = 1;
  }
  if(ev.keyCode == 68) { //d
    wasdDown[3] = 1;
  }
}

function keyUp(ev) {
  if(ev.keyCode == 87) { //w
    wasdDown[0] = 0;
  }
  if(ev.keyCode == 65) { //a
    wasdDown[1] = 0;
  }
  if(ev.keyCode == 83) { //s
    wasdDown[2] = 0;
  }
  if(ev.keyCode == 68) { //d
    wasdDown[3] = 0;
  }
}

    function addTextureToGeometry() {
      var textureFile = document.getElementById("addpic").files[0];
      var textureReader = new FileReader();
      var textureReader = new FileReader();
      textureReader.onload = function(event) {		
        
        //var texture = new MultiTextureCube(event.target.result);
        texture = event.target.result;
      }
      textureReader.readAsDataURL(textureFile);
      
    }