/**
 * Specifies a WebGL scene.
 *
 * @author "Adesh Kumar"
 * @this {Scene}
 */
class Scene {
  /**
   * Constructor for Scene.
   *
   * @constructor
   */
  constructor() {
    this.geometries = []; // Geometries being drawn on canvas new Cube(0.5, 0, 2, 0)
    this.cPitch = 0;
    this.cYaw = 0;
    gl.clearColor(0,0,0,1)
    gl.enable(gl.DEPTH_TEST);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  }

  rotateCamera(x, y){
    this.cPitch += y;
    this.cYaw += x;
    //Check that we dont go upside down
    if(this.cPitch < -90){
      this.cPitch = -90;
    }
    if(this.cPitch > 90){
     this.cPitch = 90;
   }
   }

  moveCamera(x, y, z) {
    this.cPos[0] -= z*Math.cos(this.cYaw * Math.PI/180) - x*Math.sin(-this.cYaw * Math.PI/180);
    this.cPos[1] += y;
    this.cPos[2] -= z*Math.sin(this.cYaw * Math.PI/180) - x*Math.cos(-this.cYaw * Math.PI/180);
  }
  /**
   * Adds the given geometry to the the scene.
   *
   * @param {Geometry} geometry Geometry being added to scene
   */
  addGeometry(geometry) {
    this.geometries.push(geometry)
  }

  /**
   * Updates the animation for each geometry in geometries.
   */
  updateAnimation() {
    for (var i = 0; i < this.geometries.length; i++) {
      this.geometries[i].updateAnimation()
    }
  }

  /**
   * Renders all the Geometry within the scene.
   */
  render() {
    gl.clear(gl.COLOR_BUFFER_BIT);
    for( var i = 0; i < this.geometries.length; i++){
      this.geometries[i].render();
    }
  }
}

