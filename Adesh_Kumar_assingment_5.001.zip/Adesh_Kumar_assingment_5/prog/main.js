/**
 * Function called when the webpage loads.
 */
var gl;
var canvas;
var boolean = false;
var scene;
var shape_size;
var RGB = []; //point color for next point, [R G B A]

function main() {
   // Retrieve <canvas> element
   canvas = document.getElementById('webgl');

   canvas.width  = window.innerWidth;
   canvas.height = window.innerHeight - 60
   gl = getWebGLContext(canvas)
  
   // Get the rendering context for WebGL
   gl = getWebGLContext(canvas);

   scene = new Scene(gl);

   var program = createShader(gl, ASSIGN4_VSHADER, ASSIGN4_FSHADER);
   useShader(gl, program);
   
   //calls the eventFunction.js
   initEventHandelers();

  tick();

}

function resize() {
  gl.canvas.width  = window.innerWidth;
  gl.canvas.height = window.innerHeight - 60;
  gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
  
}

/**
 * Samples the color of each pixel in an image.
 *
 * @param {Image} image The image whose color data is being sampled
 * @returns {Array} A 1-D array of RGBA values in row-major order
 */
function sampleImageColor(image) {
  var canvas = document.createElement('canvas');

  canvas.height = image.height;
  canvas.width = image.width;
  console.log(canvas);
  var context = canvas.getContext('2d');
  context.drawImage(image, 0, 0);

  var colorData = context.getImageData(0, 0, image.width, image.height).data;

  return colorData;
}
